> <img src="./xowwnrbn.png"
> style="width:8.26667in;height:11.68947in" /><img src="./mcgssclk.png"
> style="width:2.06399in;height:3.48296in" />Libft
>
> Your very first own library
>
> *Summary:*
>
> *This* *project* *is* *about* *coding* *a* *C* *library.*
>
> *It* *will* *contain* *a* *lot* *of* *general* *purpose* *functions*
> *your* *programs* *will* *rely* *upon.*
>
> *Version:* *16.4*

<img src="./ynijrihe.png"
style="width:8.26667in;height:11.68947in" />**Contents**

**I** **Introduction** **2**

**II** **Common** **Instructions** **3**

**III** **Mandatory** **part** **5** III.1 Technical considerations . .
. . . . . . . . . . . . . . . . . . . . . . . . 5 III.2 Part 1 - Libc
functions . . . . . . . . . . . . . . . . . . . . . . . . . . 6 III.3
Part 2 - Additional functions . . . . . . . . . . . . . . . . . . . . .
. . 7

**IV** **Bonus** **part** **11**

**V** **Submission** **and** **peer-evaluation** **15**

> 1

<img src="./znd2k1os.png"
style="width:8.26667in;height:11.68947in" />**Chapter** **I**

**Introduction**

C programming can be very tedious when one doesn’t have access to the
highly useful standard functions. This project is about understanding
the way these functions work, implementing and learning to use them.
Your will create your own library. It will be helpful since you will use
it in your next C school assignments.

Take the time to expand your libft throughout the year. However, when
working on a new project, don’t forget to ensure the functions used in
your library are allowed in the project guidelines.

> 2

<img src="./bxv4zrut.png"
style="width:8.26667in;height:11.68947in" />**Chapter** **II**

**Common** **Instructions**

> • Your project must be written in C.
>
> • Your project must be written in accordance with the Norm. If you
> have bonus files/functions, they are included in the norm check and
> you will receive a 0 if there is a norm error inside.
>
> • Your functions should not quit unexpectedly (segmentation fault, bus
> error, double free, etc) apart from undefined behaviors. If this
> happens, your project will be considered non functional and will
> receive a 0 during the evaluation.
>
> • All heap allocated memory space must be properly freed when
> necessary. No leaks will be tolerated.
>
> • If the subject requires it, you must submit a Makefile which will
> compile your source files to the required output with the flags -Wall,
> -Wextra and -Werror, use cc, and your Makefile must not relink.
>
> • Your Makefile must at least contain the rules \$(NAME), all, clean,
> fclean and re.
>
> • To turn in bonuses to your project, you must include a rule bonus to
> your Makefile, which will add all the various headers, libraries or
> functions that are forbidden on the main part of the project. Bonuses
> must be in a different file \_bonus.{c/h} if the subject does not
> specify anything else. Mandatory and bonus part evaluation is done
> separately.
>
> • If your project allows you to use your libft, you must copy its
> sources and its associated Makefile in a libft folder with its
> associated Makefile. Your project’s Makefile must compile the library
> by using its Makefile, then compile the project.
>
> • We encourage you to create test programs for your project even
> though this work **won’t** **have** **to** **be** **submitted**
> **and** **won’t** **be** **graded**. It will give you a chance to
> easily test your work and your peers’ work. You will find those tests
> especially useful during your defence. Indeed, during defence, you are
> free to use your tests and/or the tests of the peer you are
> evaluating.
>
> • Submit your work to your assigned git repository. Only the work in
> the git reposi-tory will be graded. If Deepthought is assigned to
> grade your work, it will be done
>
> 3

<img src="./vtvbpoyo.png"
style="width:8.26667in;height:11.68947in" />Libft Your very first own
library

> after your peer-evaluations. If an error happens in any section of
> your work during Deepthought’s grading, the evaluation will stop.
>
> 4

<img src="./ohlnbftg.png"
style="width:8.26667in;height:11.68947in" />**Chapter** **III**

**Mandatory** **part**

**III.1** **Technical** **considerations**

> • Declaring global variables is forbidden.
>
> • If you need helper functions to split a more complex function,
> define them as static functions. This way, their scope will be limited
> to the appropriate file.
>
> • Place all your files at the root of your repository.
>
> • Turning in unused files is forbidden.
>
> • Every .c files must compile with the flags -Wall -Wextra -Werror.
>
> • You must use the command ar to create your library. Using the
> libtool command is forbidden.
>
> • Your libft.a has to be created at the root of your repository.
>
> 5

<img src="./zegswnrz.png"
style="width:8.26667in;height:11.68947in" /><img src="./5knp2bjt.png"
style="width:0.43142in;height:0.46267in" /><img src="./m22aaz0o.png"
style="width:0.17361in;height:0.15104in" /><img src="./j4g4nfok.png"
style="width:0.43142in;height:0.46354in" /><img src="./5fehicaq.png"
style="width:0.17361in;height:0.15104in" />Libft Your very first own
library

**III.2** **Part** **1** **-** **Libc** **functions**

To begin, you must redo a set of functions from the libc. Your functions
will have the same prototypes and implement the same behaviors as the
originals. They must comply with the way they are defined in their man.
The only difference will be their names. They will begin with the ’ft\_’
prefix. For instance, strlen becomes ft_strlen.

> Some of the functions’ prototypes you have to redo use the ’restrict’
> qualifier. This keyword is part of the c99 standard. It is therefore
> forbidden to include it in your own prototypes and to compile your
> code with the -std=c99 flag.

You must write your own function implementing the following original
ones. They do not require any external functions:

> • isalpha
>
> • isdigit
>
> • isalnum
>
> • isascii
>
> • isprint
>
> • strlen
>
> • memset
>
> • bzero
>
> • memcpy
>
> • memmove
>
> • strlcpy
>
> • strlcat

• toupper

• tolower

• strchr

• strrchr

• strncmp

• memchr

• memcmp

• strnstr

• atoi

> In order to implement the two following functions, you will use
> malloc():
>
> • calloc
>
> • strdup
>
> Depending on your current operating system, the calloc man page and
> the function’s behavior may differ. The following instruction
> supersedes what you can find in the man page: If nmemb or size is 0,
> then calloc() returns a unique pointer value that can later be
> successfully passed to free().
>
> 6

<img src="./scxw2not.png"
style="width:8.26667in;height:11.68947in" /><img src="./mmztvnxn.png"
style="width:0.43142in;height:0.46354in" /><img src="./2qe4u3b4.png"
style="width:0.17361in;height:0.15191in" />Libft Your very first own
library

**III.3** **Part** **2** **-** **Additional** **functions**

In this second part, you must develop a set of functions that are either
not in the libc, or that are part of it but in a different form.

> Some of the following functions can be useful for writing the
> functions of Part 1.
>
> 7

<img src="./eurmrmgy.png"
style="width:8.26667in;height:11.68947in" />Libft Your very first own
library

> 8

<img src="./1hs00yxg.png"
style="width:8.26667in;height:11.68947in" />Libft Your very first own
library

> 9

<img src="./w10xq50a.png"
style="width:8.26667in;height:11.68947in" />Libft Your very first own
library

> 10

<img src="./c42g22wh.png"
style="width:8.26667in;height:11.68947in" /><img src="./n4fvulh0.png"
style="width:0.63021in;height:0.55208in" />**Chapter** **IV**

**Bonus** **part**

If you completed the mandatory part, do not hesitate to go further by
doing this extra one. It will bring bonus points if passed successfully.

Functions to manipulate memory and strings is very useful. But you will
soon discover that manipulating lists is even more useful.

You have to use the following structure to represent a node of your
list. Add its declaration to your libft.h file:

> **typedef** **struct** {
>
> **void**
>
> **struct** s_list }

s_list

> \*content; \*next; t_list;
>
> The members of the t_list struct are:
>
> • content: The data contained in the node. void \* allows to store any
> kind of data.
>
> • next: The address of the next node, or NULL if the next node is the
> last one.
>
> In your Makefile, add a make bonus rule to add the bonus functions to
> your libft.a.
>
> The bonus part will only be assessed if the mandatory part is PERFECT.
> Perfect means the mandatory part has been integrally done and works
> without malfunctioning. If you have not passed ALL the mandatory
> requirements, your bonus part will not be evaluated at all.
>
> 11

<img src="./do3cb3f3.png"
style="width:8.26667in;height:11.68947in" />Libft Your very first own
library

> Implement the following functions in order to easily use your lists.
>
> 12

<img src="./o4eco0ty.png"
style="width:8.26667in;height:11.68947in" />Libft Your very first own
library

> 13

<img src="./h4f0evoe.png"
style="width:8.26667in;height:11.68947in" />Libft Your very first own
library

> 14

<img src="./c2wbczfy.png"
style="width:8.26667in;height:11.68947in" /><img src="./wpqwcemz.png"
style="width:0.65034in;height:0.71027in" />**Chapter** **V**

**Submission** **and** **peer-evaluation**

Turn in your assignment in your Git repository as usual. Only the work
inside your repos-itory will be evaluated during the defense. Don’t
hesitate to double check the names of your files to ensure they are
correct.

> Place all your files at the root of your repository.
>
> Rnpu cebwrpg va gur 42 Pbzzba Pber pbagnvaf na rapbqrq uvag. Sbe rnpu
> pvepyr, bayl bar cebwrpg cebivqrf gur pbeerpg uvag arrqrq sbe gur arkg
> pvepyr. Guvf punyyratr vf vaqvivqhny, jvgu n svany cevmr sbe
>
> bar fghqrag. Fgnss zrzoref znl cnegvpvcngr ohg ner abg ryvtvoyr sbe n
> cevmr. Ner lbh nzbat gur irel svefg gb fbyir n pvepyr? Fraq gur uvagf
> jvgu rkcynangvbaf gb by@42.se gb or nqqrq gb gur yrnqreobneq. Gur uvag
> sbe guvf svefg cebwrpg, juvpu znl pbagnva nantenzzrq jbeqf, vf: Jbys
> bs ntragvir cnegvpyrf gung qvfcebir terral gb lbhe ubzrf qan gung
> cebjfr lbhe fgbby
>
> 15
